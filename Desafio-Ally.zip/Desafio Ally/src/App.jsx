import './App.css'
import './stylesLibMultiSelect.css'
import Footer from './components/Footer/Footer'
import Formulario from './components/Formulario/Formulario'
import Header from './components/Header/Header'

function App() {

  return (
    <div className="App">
      <Header/>
      <Formulario />
      <Footer/>
    </div>
  )
}

export default App
