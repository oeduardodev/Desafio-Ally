import style from "./Header.module.css"
function Header(){
    return(
        <header className={style.Cabecalho}>
           <h1>Desafio Ally</h1> 
        </header>
    )
}

export default Header