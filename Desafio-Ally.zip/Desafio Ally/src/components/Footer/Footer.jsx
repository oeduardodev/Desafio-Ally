import style from "./Footer.module.css"

function Footer(){
    return(
        <footer className={style.Footer} >
            <p>Desenvolvido por Eduardo Leite</p>
        </footer>
  
    )
}

export default Footer