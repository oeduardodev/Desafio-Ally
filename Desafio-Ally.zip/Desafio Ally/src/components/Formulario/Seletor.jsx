import { useEffect, useState } from "react";
import Multiselect from "multiselect-react-dropdown";

function Seletor() {
  const [paises, setPaises] = useState([]);
  const [cidades, setCidades] = useState([]);

  useEffect(() => {
    fetch("https://amazon-api.sellead.com/country", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((resp) => resp.json())
      .then((data) => {
        setPaises(data.map((item) => item.name_ptbr));
      });

    fetch("https://amazon-api.sellead.com/city", {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((resp) => resp.json())
      .then((data) => {
        setCidades(data.map((item) => item.name_ptbr));
      });
  }, []);

  return (
    <>
      <label>Países:</label>
      <Multiselect 
        isObject={false}
        onRemove={(event) => {
          setCidades(paises.map((item) => item != event.target.value));
        }}
        onSelect={(event) => {
          if (paises.find(event.target.value)) {
            setPaises(paises.map((item) => item != event.target.value));
          } else {
            setPaises(...paises, event.target.value);
          }
        }}
        options={paises}
  
        showCheckbox
      />

      <label>Cidades:</label>

      <Multiselect
        isObject={false}
        onRemove={(event) => {
          setCidades(cidades.map((item) => item != event.target.value));
        }}
        onSelect={(event) => {
          if (cidades.find(event.target.value)) {
            setCidades(cidades.map((item) => item != event.target.value));
          } else {
            setCidades(...cidades, event.target.value);
          }
        }}
        options={cidades}
      
        showCheckbox
      />
    </>
  );
}

export default Seletor;
