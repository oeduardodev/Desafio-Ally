import style from "./Formulario.module.css"
import Seletor from "./Seletor";
import InputMask from "react-input-mask"

import { useState } from "react";


function Formulario({ }) {

  const [cell, setCell] = useState('')

  return( 
    <div>
        <form className={style.Formulario}>
       
            <legend><i>DADOS PESSOAIS</i></legend>
            <label>Usuario:</label>
            <input className={style.FormInput} type="text" required />

            <label>Email:</label>
            <input className={style.FormInput}  type="email" required  />

            <label>Telefone:</label>
            <InputMask mask="(99) 9999-9999" className={style.FormInput} required />


            <label>CPF:</label>
            <InputMask mask="999.999.999-99" className={style.FormInput} required/>
     
            <legend><i>DESTINOS DE INTERESSE</i></legend>
            <Seletor/>
          
            <input className={style.Botao} type="submit" />

        </form>
    </div>
  ) 
}

export default Formulario;
